//npm i express express-session express-validator bcryptjs mysql2 cors nodemon

const mysql = require('mysql2');

const dbConnection = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'demo',
    port: '8889'
});

module.exports = dbConnection.promise();